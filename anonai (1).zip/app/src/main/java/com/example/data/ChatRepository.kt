package com.example.data

import kotlinx.coroutines.flow.Flow

class ChatRepository(private val messageDao: MessageDao) {
    val allMessages: Flow<List<MessageEntity>> = messageDao.getAllMessages()

    suspend fun insertMessage(message: MessageEntity): Long {
        return messageDao.insertMessage(message)
    }

    suspend fun clearHistory() {
        messageDao.clearHistory()
    }

    suspend fun deleteMessageById(id: Int) {
        messageDao.deleteMessageById(id)
    }
}
