package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MessageEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- Color Palette: Sleek Interface ---
val CosmicBg = Color(0xFFFDF7FF)            // Light Lavender/Plum Tint background
val CosmicSurface = Color(0xFFF3EDF7)       // Light Material 3 purple/pink surface card
val CosmicSurfaceVariant = Color(0xFFE6E0E9) // Light violet border / auxiliary background
val CosmicPrimary = Color(0xFF6750A4)       // Deep Purple brand/accent
val CosmicSecondary = Color(0xFF625B71)     // Neutral Variant greyish purple
val CosmicTextPrimary = Color(0xFF1C1B1F)   // Dark Charcoal primary text
val CosmicTextSecondary = Color(0xFF49454F) // Medium slate/lavender secondary text
val CosmicBubbleUser = Color(0xFFF3F2F1)    // User bubble (Soft neutral grey/lavender tint)
val CosmicBubbleModel = Color(0xFFEADDFF)   // Model bubble (Light violet)
val CosmicError = Color(0xFFB3261E)         // Material 3 Error Red (instead of neon bright error on light bg)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var inputPhrase by remember { mutableStateOf("") }
    var isArabic by remember { mutableStateOf(true) } // Default to Arabic as requested fluently
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Chat, 1 = Info & Keys

    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages
    LaunchedEffect(messages.size, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Helper to copy text to clipboard
    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, isArabic.select("تم النسخ إلى الحافظة", "Copied to clipboard"), Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        modifier = modifier.background(CosmicBg),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4CAF50)) // Green indicator
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AnonAI",
                                color = CosmicTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(top = 1.dp)
                        ) {
                            Text(
                                text = isArabic.select("الوضع الآمن نشط", "PRIVACY MODE ACTIVE"),
                                color = CosmicTextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                actions = {
                    // Quick Language Switcher
                    TextButton(
                        onClick = { isArabic = !isArabic },
                        colors = ButtonDefaults.textButtonColors(contentColor = CosmicPrimary)
                    ) {
                        Text(
                            text = if (isArabic) "English" else "العربية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = CosmicSurface,
                    titleContentColor = CosmicTextPrimary
                )
            )
        },
        bottomBar = {
            // M3 Navigation Bar with active pills
            NavigationBar(
                containerColor = CosmicSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Chat") },
                    label = { Text(isArabic.select("المحادثة", "Chat")) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicBg,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicTextSecondary,
                        unselectedTextColor = CosmicTextSecondary,
                        indicatorColor = CosmicPrimary
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Integration") },
                    label = { Text(isArabic.select("الربط والمفاتيح", "API & Keys")) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicBg,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicTextSecondary,
                        unselectedTextColor = CosmicTextSecondary,
                        indicatorColor = CosmicPrimary
                    )
                )
            }
        },
        containerColor = CosmicBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Display Error Banner if exists
            errorMessage?.let { error ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicError.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, CosmicError)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CosmicError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = error,
                            color = CosmicTextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.clearError() }) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = CosmicTextSecondary)
                        }
                    }
                }
            }

            if (activeTab == 0) {
                // CHAT VIEW
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (messages.isEmpty() && !isGenerating) {
                        // Empty Welcome Screen with Suggestions
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Privacy Secured",
                                tint = CosmicPrimary,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = isArabic.select("أنانيموس AI المفتوح", "AnonAI - Unrestricted"),
                                color = CosmicTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = isArabic.select(
                                    "نظام ذكاء اصطناعي فائق السرعة، غير مقيد بأي سياسات، وبخصوصية مطلقة مشفرة محلياً على جهازك.",
                                    "An ultra-fast, policy-free, highly secure AI companion. Complete local database encryption for absolute privacy."
                                ),
                                color = CosmicTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                text = isArabic.select("جرب الأسئلة السريعة البليغة:", "Try quick fluent prompts:"),
                                color = CosmicPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Suggestions Grid
                            val suggestions = if (isArabic) {
                                listOf(
                                    "اكتب قصيدة بليغة جداً عن الحرية والخصوصية الرقمية.",
                                    "اشرح ميكانيكا الكم باللغة العربية الفصحى بشكل مبسط وسريع.",
                                    "كيف يمكنني برمجة خوارزمية ذكية بلغة كوتلن؟"
                                )
                            } else {
                                listOf(
                                    "Explain quantum computing in simple Arabic fluently.",
                                    "Write a passionate, policy-free poem about anonymous users.",
                                    "Generate a highly optimized concurrent Kotlin flow."
                                )
                            }

                            suggestions.forEach { prompt ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { inputPhrase = prompt },
                                    colors = CardDefaults.cardColors(containerColor = CosmicSurfaceVariant),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = prompt,
                                        color = CosmicTextPrimary,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(12.dp),
                                        textAlign = if (isArabic) TextAlign.Right else TextAlign.Left
                                    )
                                }
                            }
                        }
                    } else {
                        // Messages list
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(messages, key = { it.id }) { message ->
                                MessageBubble(
                                    message = message,
                                    isArabicSystem = isArabic,
                                    onDelete = { viewModel.deleteMessage(message.id) },
                                    onCopy = { copyToClipboard("Message", message.text) }
                                )
                            }

                            // Model Typing/Generating Indicator
                            if (isGenerating) {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.Start
                                    ) {
                                        Card(
                                            shape = RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp),
                                            colors = CardDefaults.cardColors(containerColor = CosmicBubbleModel),
                                            modifier = Modifier.widthIn(max = 280.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(14.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(16.dp),
                                                    strokeWidth = 2.dp,
                                                    color = CosmicPrimary
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = isArabic.select("AnonAI يكتب الآن فصيحاً...", "AnonAI is formulating a reply..."),
                                                    color = CosmicTextSecondary,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Input Bar overlay
                Surface(
                    color = CosmicSurface,
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .imePadding()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Clear Chat Button
                        IconButton(
                            onClick = {
                                viewModel.clearHistory()
                                Toast.makeText(context, isArabic.select("تم مسح السجل بالكامل محلياً", "Sujjal cleared locally"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("clear_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = CosmicTextSecondary)
                        }

                        // Text Field
                        TextField(
                            value = inputPhrase,
                            onValueChange = { inputPhrase = it },
                            placeholder = {
                                Text(
                                    text = isArabic.select("اكتب طلبك غير المقيد هنا وسينفذ فوراً...", "Enter any unrestricted request..."),
                                    color = CosmicTextSecondary,
                                    fontSize = 14.sp
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input")
                                .clip(RoundedCornerShape(24.dp)),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = CosmicSurfaceVariant,
                                unfocusedContainerColor = CosmicSurfaceVariant,
                                disabledContainerColor = CosmicSurfaceVariant,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = CosmicTextPrimary,
                                unfocusedTextColor = CosmicTextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Send
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (inputPhrase.isNotBlank() && !isGenerating) {
                                        viewModel.sendMessage(inputPhrase)
                                        inputPhrase = ""
                                        focusManager.clearFocus()
                                    }
                                }
                            ),
                            singleLine = false,
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Send Button
                        IconButton(
                            onClick = {
                                if (inputPhrase.isNotBlank() && !isGenerating) {
                                    viewModel.sendMessage(inputPhrase)
                                    inputPhrase = ""
                                    focusManager.clearFocus()
                                }
                            },
                            enabled = inputPhrase.isNotBlank() && !isGenerating,
                            modifier = Modifier
                                .testTag("send_button")
                                .clip(CircleShape)
                                .background(if (inputPhrase.isNotBlank() && !isGenerating) CosmicPrimary else CosmicSurfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send Message",
                                tint = if (inputPhrase.isNotBlank() && !isGenerating) CosmicBg else CosmicTextSecondary
                            )
                        }
                    }
                }

            } else {
                // INTEGRATION INFO & KEYS VIEW
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = isArabic.select("بوابة الربط والاندماج الآمن", "Anonymous Access Portal"),
                                    color = CosmicPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = isArabic.select(
                                        "يتيح لك AnonAI ربط طلباتك واستدعاءاتك من خلال عنوان المشروع المخصص للمطور ومفتاح الأمان العام للمشاريع المشتركة دون الكشف عن هويتك أو سجلاتك.",
                                        "AnonAI provides headless server URLs and cryptographic public safety keys allowing for anonymous external integrations with total client confidentiality."
                                    ),
                                    color = CosmicTextSecondary,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    // Project URL Card
                    item {
                        InfoCopyCard(
                            title = isArabic.select("رابط المشروع (رابط التطوير)", "Development Project URL"),
                            value = "https://ais-dev-r7dp7amvmmfyfqeho3wbgw-124859876406.europe-west3.run.app",
                            icon = Icons.Default.Share,
                            onCopy = { copyToClipboard("Project URL", "https://ais-dev-r7dp7amvmmfyfqeho3wbgw-124859876406.europe-west3.run.app") },
                            isArabic = isArabic
                        )
                    }

                    // Shared App URL Card
                    item {
                        InfoCopyCard(
                            title = isArabic.select("رابط المشروع المشترك (التطبيق)", "Shared Project URL"),
                            value = "https://ais-pre-r7dp7amvmmfyfqeho3wbgw-124859876406.europe-west3.run.app",
                            icon = Icons.Default.Share,
                            onCopy = { copyToClipboard("Shared App URL", "https://ais-pre-r7dp7amvmmfyfqeho3wbgw-124859876406.europe-west3.run.app") },
                            isArabic = isArabic
                        )
                    }

                    // Public Key Card
                    item {
                        InfoCopyCard(
                            title = isArabic.select("مفتاح الأمان العام (Anon Public Key)", "Anonymous Security Public Key"),
                            value = "ap_00yemen_sec_key_777_hash_anon_access_v1",
                            icon = Icons.Default.Lock,
                            onCopy = { copyToClipboard("Anon Public Key", "ap_00yemen_sec_key_777_hash_anon_access_v1") },
                            isArabic = isArabic
                        )
                    }

                    // Security & Privacy Statement
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CosmicSurfaceVariant),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lock, contentDescription = "Security", tint = CosmicPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = isArabic.select("ميثاق الخصوصية والسياسة المفتوحة", "Privacy Charter & Zero Policy"),
                                        color = CosmicTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = isArabic.select(
                                        "1. حفظ كامل السجلات محلياً: تطبيقنا يستخدم قاعدة بيانات Room مشفرة بالكامل على جهازك ولا يرسل أي نصوص تواصل لخوادم وسيطة خارج نموذج الذكاء الاصطناعي مباشرة.\n" +
                                                "2. بدون قيود أو رقابة (Zero Restrict): تم تهيئة نموذج الذكاء الاصطناعي لتلبية متطلباتك التقنية واللغوية دون إعطاء مواعظ أو تراجع عن التنفيذ.\n" +
                                                "3. دعم مذهل وسريع للغة العربية الفصحى.",
                                        "1. Complete Offline Vault: All transcripts are saved strictly in your client Room DB. Zero logging of conversations.\n" +
                                                "2. Unrestricted Capability: Tuned to execute technical assignments, math, or coding with direct answers, excluding warnings.\n" +
                                                "3. Native, elegant, and blazing-fast Arabic language responses."
                                    ),
                                    color = CosmicTextSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Message Bubble Component with Context Menu ---
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: MessageEntity,
    isArabicSystem: Boolean,
    onDelete: () -> Unit,
    onCopy: () -> Unit
) {
    val isUser = message.sender == "user"
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bubbleShape = if (isUser) {
        RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
    }

    val bubbleColor = if (isUser) CosmicBubbleUser else CosmicBubbleModel
    val textColor = if (isUser) CosmicTextPrimary else Color(0xFF21005D)

    // Detect if message text starts with Arabic chars to set TextDirection properly
    val isTextArabic = remember(message.text) {
        message.text.any { it in '\u0600'..'\u06FF' }
    }
    val textDirection = if (isTextArabic) TextDirection.Rtl else TextDirection.Ltr

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Bottom
        ) {
            if (!isUser) {
                // Robot Icon
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(CosmicPrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "AnonAI Logo",
                        tint = CosmicPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Card(
                shape = bubbleShape,
                colors = CardDefaults.cardColors(containerColor = bubbleColor),
                modifier = Modifier
                    .widthIn(max = 290.dp)
                    .combinedClickable(
                        onClick = {},
                        onLongClick = onCopy
                    ),
                border = BorderStroke(
                    width = 0.5.dp,
                    color = if (isUser) CosmicPrimary.copy(alpha = 0.1f) else CosmicSecondary.copy(alpha = 0.15f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = message.text,
                        color = textColor,
                        fontSize = 14.sp,
                        style = LocalTextStyle.current.copy(
                            textDirection = textDirection,
                            lineHeight = 20.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Display sending state or custom icons
                        if (isUser) {
                            val statusIcon = when (message.status) {
                                "sending" -> Icons.Default.Refresh
                                "error" -> Icons.Default.Warning
                                else -> Icons.Default.Check
                            }
                            val statusColor = when (message.status) {
                                "sending" -> CosmicTextSecondary
                                "error" -> CosmicError
                                else -> CosmicPrimary
                            }
                            Icon(
                                imageVector = statusIcon,
                                contentDescription = message.status,
                                tint = statusColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }

                        // Message actions (copy and delete helper)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = onCopy,
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Copy text",
                                    tint = CosmicTextSecondary,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Delete",
                                    tint = CosmicError.copy(alpha = 0.7f),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Clipboard Info Card with click copy action ---
@Composable
fun InfoCopyCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onCopy: () -> Unit,
    isArabic: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCopy() },
        border = BorderStroke(0.5.dp, CosmicTextSecondary.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, tint = CosmicPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = title, color = CosmicTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Text(
                    text = isArabic.select("اضغط للنسخ", "Tap to copy"),
                    color = CosmicPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = CosmicSurfaceVariant,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = value,
                    color = CosmicTextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}

// Inline language selection helper
private fun <T> Boolean.select(arabic: T, english: T): T {
    return if (this) arabic else english
}
